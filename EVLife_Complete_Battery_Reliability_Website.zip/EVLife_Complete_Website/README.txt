EVLife — COMPLETE BATTERY RELIABILITY & DEGRADATION WEBSITE
===========================================================

RUN THE WEBSITE
1. Extract this ZIP folder.
2. Open index.html in Chrome, Edge, Firefox, or another modern browser.
3. No installation, server, API key, or internet connection is required.
4. Use the left navigation to open each of the five modules.

MODULES
1. Overview dashboard
2. Battery Information & Input (temperature, cycle count, fast-charge %, C-rate,
   average velocity, road gradient)
3. Battery Degradation Prediction (SoH, capacity fade, 80% threshold)
4. Weibull Reliability (R(t), hazard rate, B10, B50, scenario comparison)
5. Monte Carlo Simulation (10,000 samples, mean, standard deviation, P5, P95)
6. Model Validation (R², RMSE, MAE, residual chart, descriptive one-sample K-S)

IMPORTANT SCIENTIFIC SCOPE
This is a working browser-based research demonstration. It does not claim to
reproduce fitted results from the uploaded PowerPoint decks. The decks could not
be reopened by the file service while building this package, so the website does
not invent their missing equations or parameter estimates.

The degradation page uses a transparent linear demonstration equation:
    SoH(cycles) = initial SoH - fade rate (%) * cycles / 1000
You must replace the illustrative fade-rate setting with a rate fitted from
your research dataset, or replace the equation with the exact PPT model.

The Weibull page uses:
    R(t) = exp(-(t / eta)^beta)
    h(t) = (beta / eta) * (t / eta)^(beta - 1)
    Bq = eta * (-ln(1-q))^(1/beta)
Shape and scale defaults are illustrative. Enter fitted beta and eta from your
study. Scenario comparisons are illustrative parameter changes, not empirical
effects inferred from operating conditions.

Monte Carlo samples are drawn from the configured two-parameter Weibull model.
They are not a separately trained operating-profile prediction model.

Validation metrics are calculated from the observed and predicted lists entered
by the user. The K-S statistic is descriptive against a normal reference whose
parameters are estimated from the same sample; no p-value is claimed. AIC is
not calculated for arbitrary observed/predicted pairs and is marked not
applicable until a likelihood model is specified.

DATA AND PRIVACY
The current battery profile is stored in browser localStorage on this device.
No data is sent to a server. Clear browser site data or use Reset demo to reset
the example profile.

FILES
- index.html : website structure
- styles.css : responsive design
- app.js     : interactive calculations, validation, charts and navigation
- README.txt : setup and scientific-scope notes

This package is a frontend-only website. It does not include Flask, MySQL, user
accounts, cloud hosting, or a trained machine-learning model.

const $=id=>document.getElementById(id);
const state={profile:null,sim:null,metrics:null};
const labels=[["temperature","Temperature","°C"],["cycles","Cycle count","cycles"],["fastCharge","Fast charge","%"],["cRate","Average C-rate","C"],["velocity","Average velocity","km/h"],["gradient","Road gradient","%"]];
const num=(id)=>Number($(id).value);
const fmt=(v,d=2)=>Number.isFinite(v)?v.toLocaleString(undefined,{maximumFractionDigits:d}):"—";
const pct=v=>Number.isFinite(v)?(v*100).toFixed(2)+"%":"—";
function save(){try{localStorage.setItem("evlife-profile",JSON.stringify(state.profile));}catch(e){}}
function load(){try{state.profile=JSON.parse(localStorage.getItem("evlife-profile"))}catch(e){} if(!state.profile)state.profile={temperature:35,cycles:500,fastCharge:40,cRate:1.5,velocity:60,gradient:5};}
function showProfile(){ $("profileGrid").innerHTML=labels.map(([k,l,u])=>`<div class="profile-item"><small>${l}</small><b>${fmt(state.profile[k])} ${u}</b></div>`).join(""); $("overviewProfile").innerHTML=labels.map(([k,l,u])=>`<div class="profile-item"><small>${l}</small><b>${fmt(state.profile[k])} ${u}</b></div>`).join(""); $("profileStatus").textContent="SAVED"; }
function fillForm(){for(const [k] of labels)$(k).value=state.profile[k];}
function sohAt(cycles){const initial=num("initialSoh"),rate=num("fadeRate");return Math.max(0,initial-rate*cycles/1000);}
function updateDegradation(){
 const c=state.profile.cycles, soh=sohAt(c), initial=num("initialSoh"), rate=num("fadeRate"), perYear=num("cyclesYear"), threshold=80;
 const cycles80=rate>0&&initial>threshold?(initial-threshold)*1000/rate:Infinity;
 $("currentSoh").textContent=fmt(soh)+"%";$("capacityFade").textContent=fmt(initial-soh)+"%";
 $("cycles80").textContent=Number.isFinite(cycles80)?fmt(cycles80,0):"Not reached";
 $("years80").textContent=Number.isFinite(cycles80)?fmt(Math.max(0,cycles80-c)/perYear)+" years":"Not reached";
 $("degradationText").textContent=`At ${fmt(c,0)} cycles, the demonstration model estimates SoH at ${fmt(soh)}%. The 80% threshold is reached at approximately ${fmt(cycles80,0)} total cycles (${Number.isFinite(cycles80)?fmt(cycles80/perYear)+" years from new":"not reached under these settings"}). This result depends entirely on the editable fade-rate assumption.`;
 $("ovSoh").textContent=fmt(soh)+"%";
 const horizon=Math.max(100,num("cycleHorizon")), xs=Array.from({length:21},(_,i)=>i*horizon/20), ys=xs.map(sohAt);
 drawLine("degradationChart",xs,ys,"Cycles","SoH (%)",80,100,0);
}
function weibull(t,b,e){return Math.exp(-Math.pow(Math.max(0,t)/e,b));}
function hazard(t,b,e){if(t===0&&b<1)return Infinity;if(t===0&&b===1)return 1/e;return (b/e)*Math.pow(t/e,b-1);}
function bLife(q,b,e){return e*Math.pow(-Math.log(1-q),1/b);}
function getW(){return {b:num("beta"),e:num("eta"),t:num("mission"),unit:$("distanceUnit").value||"units"}}
function updateWeibull(){
 const {b,e,t,unit}=getW(); if(!(b>0&&e>0&&t>=0))return;
 const r=weibull(t,b,e),h=hazard(t,b,e);
 $("reliabilityValue").textContent=pct(r);$("hazardValue").textContent=fmt(h,7)+" / "+unit;
 $("b10Value").textContent=fmt(bLife(.1,b,e),1)+" "+unit;$("b50Value").textContent=fmt(bLife(.5,b,e),1)+" "+unit;
 $("ovRel").textContent=pct(r);$("ovB10").textContent=fmt(bLife(.1,b,e),0)+" "+unit;
 const xmax=Math.max(e*1.5,t*1.15,1), xs=Array.from({length:41},(_,i)=>xmax*i/40);
 drawLine("reliabilityChart",xs,xs.map(x=>weibull(x,b,e)*100),"Distance ("+unit+")","Reliability (%)",null,100,0);
 const hz=xs.map(x=>Math.min(hazard(Math.max(x,.000001),b,e),10/e));
 drawLine("hazardChart",xs,hz,"Distance ("+unit+")","Hazard rate",null,Math.max(...hz)*1.1,0);
 const scenarios=[["Baseline",b,e],["Hot + fast charge",b, e*.82],["Mild + slow charge",b,e*1.18]];
 $("scenarioRows").innerHTML=scenarios.map(([name,bb,ee])=>`<tr><td>${name}</td><td>${fmt(bb)}</td><td>${fmt(ee,0)}</td><td><b>${pct(weibull(t,bb,ee))}</b></td></tr>`).join("");
 drawBars("overviewScenarioChart",scenarios.map(x=>x[0]),scenarios.map(x=>weibull(t,x[1],x[2])*100),100,"%");
}
function drawLine(id,xs,ys,xLabel,yLabel,threshold,yMaxOverride,yMin=0){
 const c=$(id);if(!c)return;const ctx=c.getContext("2d"),w=c.clientWidth||600,h=c.height;c.width=Math.max(300,w*devicePixelRatio);c.height=h*devicePixelRatio;ctx.scale(devicePixelRatio,devicePixelRatio);const W=c.width/devicePixelRatio,H=h;
 const L=48,R=12,T=15,B=34,pw=W-L-R,ph=H-T-B;ctx.clearRect(0,0,W,H);
 let ymin=yMin,ymax=yMaxOverride||Math.max(...ys)*1.12;if(ymax<=ymin)ymax=ymin+1;
 ctx.font="10px Arial";ctx.fillStyle="#7b8a81";ctx.strokeStyle="#e7eee9";ctx.lineWidth=1;
 for(let i=0;i<=4;i++){let y=T+ph*i/4,val=ymax-(ymax-ymin)*i/4;ctx.beginPath();ctx.moveTo(L,y);ctx.lineTo(W-R,y);ctx.stroke();ctx.fillText(fmt(val,1),4,y+3)}
 ctx.strokeStyle="#168357";ctx.lineWidth=2;ctx.beginPath();ys.forEach((v,i)=>{let x=L+pw*i/(ys.length-1),y=T+ph-(v-ymin)/(ymax-ymin)*ph;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke();
 if(threshold!==null){let y=T+ph-(threshold-ymin)/(ymax-ymin)*ph;ctx.strokeStyle="#d99a36";ctx.setLineDash([5,4]);ctx.beginPath();ctx.moveTo(L,y);ctx.lineTo(W-R,y);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle="#a77522";ctx.fillText("80% threshold",W-90,y-5)}
 ctx.fillStyle="#7b8a81";ctx.fillText(xLabel,L+pw/2-35,H-7);ctx.save();ctx.translate(11,T+ph/2);ctx.rotate(-Math.PI/2);ctx.fillText(yLabel,0,0);ctx.restore();
}
function drawBars(id,names,values,max,suffix=""){
 const c=$(id);if(!c)return;const ctx=c.getContext("2d"),w=c.clientWidth||600,h=c.height;c.width=w*devicePixelRatio;c.height=h*devicePixelRatio;ctx.scale(devicePixelRatio,devicePixelRatio);ctx.clearRect(0,0,w,h);const L=45,R=10,T=15,B=34,pw=w-L-R,ph=h-T-B;
 ctx.font="10px Arial";ctx.fillStyle="#7b8a81";ctx.strokeStyle="#e7eee9";for(let i=0;i<=4;i++){let y=T+ph*i/4;ctx.beginPath();ctx.moveTo(L,y);ctx.lineTo(w-R,y);ctx.stroke();ctx.fillText(fmt(max*(1-i/4),0),8,y+3)}
 const slot=pw/names.length,bw=Math.min(65,slot*.48);values.forEach((v,i)=>{let bh=Math.max(0,v/max*ph),x=L+slot*i+(slot-bw)/2,y=T+ph-bh;ctx.fillStyle="#168357";ctx.fillRect(x,y,bw,bh);ctx.fillStyle="#607168";ctx.textAlign="center";ctx.fillText(names[i],x+bw/2,h-12);ctx.fillStyle="#234b39";ctx.fillText(fmt(v,1)+suffix,x+bw/2,y-5)});ctx.textAlign="left";
}
function normal(seed){let x=Math.sin(seed*12.9898)*43758.5453;return x-Math.floor(x)}
function mulberry32(a){return function(){let t=a+=0x6D2B79F5;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}}
function runMC(){
 const {b,e,unit}=getW(),seed=Math.trunc(num("randomSeed"));if(!(b>0&&e>0)){alert("Enter positive Weibull shape and scale parameters first.");return}
 const rand=mulberry32(seed),arr=Array.from({length:10000},()=>e*Math.pow(-Math.log(1-rand()),1/b)).sort((a,b)=>a-b);
 const mean=arr.reduce((a,x)=>a+x,0)/arr.length,sd=Math.sqrt(arr.reduce((a,x)=>a+(x-mean)**2,0)/(arr.length-1)),p=q=>arr[Math.floor(q*(arr.length-1))];
 state.sim={arr,mean,sd,p5:p(.05),p95:p(.95),unit};
 $("mcMean").textContent=fmt(mean,0);$("mcStd").textContent=fmt(sd,0);$("mcP5").textContent=fmt(p(.05),0);$("mcP95").textContent=fmt(p(.95),0);$("mcUnit").textContent=unit;
 const lo=arr[0],hi=arr[arr.length-1],bins=25,counts=Array(bins).fill(0);arr.forEach(v=>counts[Math.min(bins-1,Math.floor((v-lo)/(hi-lo||1)*bins))]++);
 drawBars("histogramChart",counts.map((_,i)=>fmt(lo+(i+.5)*(hi-lo)/bins,0)),counts,Math.max(...counts),"");
 $("mcSummary").textContent=`10,000 lifetimes were sampled using β = ${b}, η = ${fmt(e,0)} ${unit}, seed ${seed}. Mean life: ${fmt(mean,1)} ${unit}; standard deviation: ${fmt(sd,1)} ${unit}; P5: ${fmt(p(.05),1)} ${unit}; P95: ${fmt(p(.95),1)} ${unit}.`;
}
function parseList(id){return $(id).value.split(/[,\s;]+/).filter(Boolean).map(Number)}
function erf(x){const s=x<0?-1:1;x=Math.abs(x);const t=1/(1+.3275911*x);const y=1-(((((1.061405429*t-1.453152027)*t)+1.421413741)*t-.284496736)*t+.254829592)*t*Math.exp(-x*x);return s*y}
function normCdf(x,mu,sd){return .5*(1+erf((x-mu)/(sd*Math.sqrt(2))))}
function calcValidation(){
 const obs=parseList("observedData"),pred=parseList("predictedData");if(obs.length<2||obs.length!==pred.length||[...obs,...pred].some(x=>!Number.isFinite(x))){$("validationMessage").textContent="Enter at least two valid values in matching-length lists.";return}
 const n=obs.length,mean=obs.reduce((a,b)=>a+b,0)/n,sse=obs.reduce((s,v,i)=>s+(v-pred[i])**2,0),sst=obs.reduce((s,v)=>s+(v-mean)**2,0),rmse=Math.sqrt(sse/n),mae=obs.reduce((s,v,i)=>s+Math.abs(v-pred[i]),0)/n,r2=sst===0?NaN:1-sse/sst;
 const sorted=[...obs].sort((a,b)=>a-b),sd=Math.sqrt(sorted.reduce((s,v)=>s+(v-mean)**2,0)/n)||1;let D=0;sorted.forEach((v,i)=>{const f=normCdf(v,mean,sd);D=Math.max(D,Math.abs((i+1)/n-f),Math.abs(i/n-f))});
 $("r2Value").textContent=fmt(r2,4);$("rmseValue").textContent=fmt(rmse,4);$("maeValue").textContent=fmt(mae,4);$("ksValue").textContent=fmt(D,4);$("sampleCount").textContent=n;$("aicValue").textContent="Not applicable";$("validationMessage").textContent="Metrics calculated for entered sample.";
 drawScatter("validationChart",obs,pred);drawBars("residualChart",obs.map((_,i)=>String(i+1)),obs.map((v,i)=>v-pred[i]),Math.max(...obs.map((v,i)=>Math.abs(v-pred[i])))*1.2||1,"");
 state.metrics={r2,rmse,mae,ks:D,n};
}
function drawScatter(id,x,y){
 const c=$(id),ctx=c.getContext("2d"),w=c.clientWidth||500,h=c.height;c.width=w*devicePixelRatio;c.height=h*devicePixelRatio;ctx.scale(devicePixelRatio,devicePixelRatio);ctx.clearRect(0,0,w,h);const L=42,R=15,T=12,B=30,all=[...x,...y],mn=Math.min(...all),mx=Math.max(...all),span=mx-mn||1,pw=w-L-R,ph=h-T-B;
 ctx.strokeStyle="#e7eee9";for(let i=0;i<=4;i++){let z=T+ph*i/4;ctx.beginPath();ctx.moveTo(L,z);ctx.lineTo(w-R,z);ctx.stroke()}
 const px=v=>L+(v-mn)/span*pw,py=v=>T+ph-(v-mn)/span*ph;ctx.strokeStyle="#c18b39";ctx.setLineDash([5,4]);ctx.beginPath();ctx.moveTo(px(mn),py(mn));ctx.lineTo(px(mx),py(mx));ctx.stroke();ctx.setLineDash([]);
 x.forEach((v,i)=>{ctx.fillStyle="#168357";ctx.beginPath();ctx.arc(px(v),py(y[i]),4,0,Math.PI*2);ctx.fill()});ctx.fillStyle="#718078";ctx.font="10px Arial";ctx.fillText("Observed",w/2-20,h-6);ctx.save();ctx.translate(11,h/2);ctx.rotate(-Math.PI/2);ctx.fillText("Predicted",0,0);ctx.restore();
}
function nav(view){document.querySelectorAll(".view").forEach(x=>x.classList.toggle("active",x.id==="view-"+view));document.querySelectorAll(".nav-link").forEach(x=>x.classList.toggle("active",x.dataset.view===view));const names={overview:"Overview",input:"Battery information",degradation:"Degradation prediction",weibull:"Weibull reliability",montecarlo:"Monte Carlo simulation",validation:"Model validation"};$("pageTitle").textContent=names[view];if(view==="overview"){updateDegradation();updateWeibull()}if(view==="degradation")updateDegradation();if(view==="weibull")updateWeibull();if(view==="montecarlo"&&state.sim)runMC();setTimeout(()=>window.dispatchEvent(new Event("resize")),20)}
document.querySelectorAll(".nav-link").forEach(b=>b.addEventListener("click",()=>nav(b.dataset.view)));document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>nav(b.dataset.go)));
$("batteryForm").addEventListener("submit",e=>{e.preventDefault();const p={};for(const [k] of labels)p[k]=Number($(k).value);if(Object.values(p).some(v=>!Number.isFinite(v))||p.cycles<0||!Number.isInteger(p.cycles)||p.fastCharge<0||p.fastCharge>100||p.cRate<0||p.velocity<0){$("inputMessage").textContent="Check the values. Cycle count must be a non-negative integer; fast charge must be 0–100%.";return}state.profile=p;save();showProfile();$("inputMessage").textContent="Battery profile saved. Analysis modules are ready.";updateDegradation();updateWeibull()});
$("batteryForm").addEventListener("reset",()=>setTimeout(()=>{for(const [k] of labels)$(k).value=state.profile[k]},0));
$("runDegradation").addEventListener("click",updateDegradation);$("runWeibull").addEventListener("click",updateWeibull);$("runSimulation").addEventListener("click",runMC);$("calculateMetrics").addEventListener("click",calcValidation);
$("loadExample").addEventListener("click",()=>{$("observedData").value="98, 95, 93, 90, 87, 84, 81";$("predictedData").value="97, 96, 92, 89, 88, 83, 82";calcValidation()});
$("resetAll").addEventListener("click",()=>{if(!confirm("Reset all settings and the saved battery profile to demonstration defaults?"))return;localStorage.removeItem("evlife-profile");location.reload()});
window.addEventListener("resize",()=>{if(document.querySelector("#view-overview").classList.contains("active"))updateWeibull();if(document.querySelector("#view-degradation").classList.contains("active"))updateDegradation();if(document.querySelector("#view-weibull").classList.contains("active"))updateWeibull();if(document.querySelector("#view-montecarlo").classList.contains("active")&&state.sim)runMC();if(document.querySelector("#view-validation").classList.contains("active")&&state.metrics)calcValidation()});
load();fillForm();showProfile();updateDegradation();updateWeibull();calcValidation();
